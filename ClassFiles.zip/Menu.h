#ifndef MENU_H
#define MENU_H

class Menu
{
    private:
        Party family;
        Milestones landmarks;
    public:
        Menu()
        {
            
        }
        
};


#endif