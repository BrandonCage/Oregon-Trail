#ifndef MILESTONES_H
#define MILESTONES_H
#include "Split.h"

class Milestones
{
    private:
        std::string FortTitles[6];
        int FortMiles[6];
        std::string RiverTitles[4];
        int RiverMiles[4];
        int Depth[4];
        std::ifstream forts;
        std::ifstream rivers;
        std::string line="";
    public:
        Milestones()
        {
            forts.open("fort-milestones.txt");
            std::string array1[2];
            std::string array2[2];
            std::string array3[2];
            for (int n=0;n<6;n++)
            {
                getline(forts, line);
                FortTitles[n]=line;
                getline(forts, line);
                split(line, 'm', array1, 2);
                FortMiles[n]=stoi(array1[0]);
            }
            rivers.open("river-milestones.txt");
            for (int m=0;m<4;m++)
            {
                getline(rivers, line);
                RiverTitles[m]=line;
                getline(rivers, line);
                split(line, 'm', array1, 2);
                RiverMiles[m]=stoi(array1[0]);
                split(array1[1], ' ', array2, 2);
                split(array2[1], 'f', array3, 2);
                Depth[m]=stoi(array3[0]);
            }
        }
        std::string getFortName(int i)
        {
            return FortTitles[i];
        }
        int getFortDistance(int i)
        {
            return FortMiles[i];
        }
        std::string getRiverName(int i)
        {
            return RiverTitles[i];
        }
        int getRiverDistance(int i)
        {
            return RiverMiles[i];
        }
        int getRiverDepth(int i)
        {
            return Depth[i];
        }
};


#endif