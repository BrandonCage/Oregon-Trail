#ifndef PARTY_H
#define PARTY_H

class Party
{
    private: 
        double money;
        Player member[5];
        int miles;
        int milestogo;
        int food;
        int oxen;
        int bullets;
        int wagonparts;
        int date;
    public:
        Party()
        {
            money=1200.00;
            miles=0;
            milestogo=2040;
            food=0;
            oxen=0;
            bullets=0;
            wagonparts=0;
            date=28;
        }
        Party(int input)
        {
            money=1200.00;
            miles=0;
            milestogo=2040;
            food=0;
            oxen=0;
            bullets=0;
            wagonparts=0;
            date=input;
        }
        void setName(std::string inputname, int inputmember)
        {
            member[inputmember].setName(inputname);
        }
        std::string getName(int input)
        {
            return member[input].getName();
        }
        void setStatus(int inputstatus, int inputmember)
        {
            member[inputmember].setStatus(inputstatus);
        }
        int getStatus(int input)
        {
            return member[input].getStatus();
        }
        std::string getDiseaseName(int input)
        {
            return member[input].getDiseaseName();
        }
        void changeMoney(double input)
        {
            money+=input;
        }
        double getMoney()
        {
            return money;
        }
        void changeMiles(int input)
        {
            miles+=input;
            milestogo-=input;
        }
        int getMiles()
        {
            return miles;
        }
        int getMilesToGo()
        {
            return milestogo;
        }
        void changeFood(int input)
        {
            food+=input;
        }
        int getFood()
        {
            return food;
        }
        void changeBullets(int input)
        {
            food+=input;
        }
        int getBullets()
        {
            return food;
        }
        void changeOxen(int input)
        {
            food+=input;
        }
        int getOxen()
        {
            return food;
        }
        void changeWagonParts(int input)
        {
            food+=input;
        }
        int getWagonParts()
        {
            return food;
        }
        void changeDate(int input)
        {
            date+=input;
        }
        int getDateInt()
        {
            return date;
        }
        void getDateString()
        {
            if (date<32)
            {
                std::cout << "March " << date;
            }
            else if(date<62)
            {
                std::cout << "April " << date-31;
            }
            else if(date<93)
            {
                std::cout << "May " << date-61;
            }
            else if(date<123)
            {
                std::cout << "June " << date-92;
            }
            else if(date<154)
            {
                std::cout << "July " << date-122;
            }
            else if(date<185)
            {
                std::cout << "August " << date-153;
            }
            else if(date<215)
            {
                std::cout << "September " << date-184;
            }
            else if(date<246)
            {
                std::cout << "October " << date-214;
            }
            else if(date<276)
            {
                std::cout << "November " << date-245;
            }
            else if(date<307)
            {
                std::cout << "December " << date-275;
            }
        }
        
        
};


#endif